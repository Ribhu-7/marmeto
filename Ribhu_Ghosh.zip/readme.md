this is a responsive project which is responsive for all devices

mobile.css - mobile devices using width below 767px
media.css - tablet devices using width between 768px and 1024px
style.css - basic css file for laptop or desktop screen with width above 1024px

kindly click on the respective choice to display the different product.
the api is fetched as told and displayed according to the different categories selected.
index.html - html file
index.js - javascript file